import math11 from '../Assets/math11.png'
import chem11 from '../Assets/chem11.png'
import phy11 from '../Assets/phy11.png'
import quize11 from '../Assets/quiz11.png'
import math12 from '../Assets/math12.png'
import chem12 from '../Assets/chem12.png'
import phy12 from '../Assets/phy12.png'
import quize12 from '../Assets/quiz12.png'

const subinfo ={
  "class11" :[
    {
      "section": "11th",
      "image": math11,
      "title": "Mathematics",
    },
    {
      "section": "Section B",
      "image": phy11,
      "title": "Physics",
      
    },
    {
      "section": "Section C",
      "image": chem11,
      "title": "Chemistry",
      
    }, {
      "section": "Section C",
      "image": quize11,
      "title": "Quize-11",
      
    }
    // Add more sections for class 11 if needed
  ],
  "class12": [
    {
      "section": "Section D",
      "image": math12,
      "title": "Mathematics",
      
    },
    {
      "section": "Section E",
      "image": phy12,
      "title": "Physics",
      "buttonText": "Practice Now"
    },
    {
      "section": "Section F",
      "image": chem12,
      "title": "Chemistry",
      "buttonText": "Practice Now"
    },
    {
      "section": "Section C",
      "image": quize12,
      "title": "Quize-12",
     
    }
    // Add more sections for class 12 if needed
  ]
}

export default subinfo;
