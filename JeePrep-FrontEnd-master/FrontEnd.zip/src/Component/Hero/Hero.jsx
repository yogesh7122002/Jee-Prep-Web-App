import React from 'react'
import './hero.css'
export default function Hero() {
  return (  
    <div className='nav-head'>
    <div className="nav-back">
     <div className="welinfo">
              <h5 id="linwel" className=''>WELCOME TO Jee Prep</h5>
              <h4 id="bston" className=''>Best Online Education Expertise</h4>
              <h5 id="tagline"></h5>
                  {/* <a href="loginregister.html"> <button id="getstart">Get Started Now -</button></a>
              <button id="viewcoursebtn">Get Started Now -</button> */}
          </div>
    </div>
    </div>
  )
}
